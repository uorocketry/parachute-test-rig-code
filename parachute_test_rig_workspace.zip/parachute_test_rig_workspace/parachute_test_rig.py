from Phidget22.Phidget import *
from Phidget22.Devices.VoltageRatioInput import *
import time
import csv
import keyboard
import serial
import serial.tools.list_ports

# ===================== General Parameters =====================

sample_interval = 100      # miliseconds
tare_samples = 20          # samples
#gains = [34558.934319198, 39000, 17544.6594758342, 17314.8997703798]
gains = [371161.0, 371161.0, 170672.8, 170020.8] # x1, x2, z, y

# ===================== DATAQ / Anemometer Setup =====================

# Define scan list and conversion ranges for the DATAQ device.
slist = [0x0000, 0x0001]   # Two channels: one for wind speed and one for wind direction
analog_ranges = [10]       # Only one analog range defined
rate_ranges = (50000, 20000, 10000, 5000, 2000, 1000, 500, 200, 100, 50, 20, 10)
range_table = []           # To be built when configuring the scan list
ser = serial.Serial()      # Set up the serial connection for the DATAQ device.

def discovery():
    """Discover the DATAQ Instruments device via serial port."""
    available_ports = list(serial.tools.list_ports.comports())
    hooked_port = ""
    for p in available_ports:
        if "VID:PID=0683" in p.hwid:
            hooked_port = p.device
            break
    if hooked_port:
        print("DATAQ device found on", hooked_port)
        ser.port = hooked_port
        ser.baudrate = 115200
        ser.timeout = 0
        ser.open()
        return True
    else:
        print("DATAQ device not found. Please connect the device.")
        input("Press ENTER to try again...")
        return False


def send_cmd(cmd):
    """Send a command to the DATAQ device and print any response."""
    ser.write((cmd + '\r').encode())
    time.sleep(0.1)
    if ser.inWaiting() > 0:
        response = ser.readline()
        try:
            decoded = response.decode().strip()
        except UnicodeDecodeError:
            decoded = response.hex()
        if decoded:
            print(decoded)


def config_scn_lst():
    """Configure the scan list and build the conversion range table."""
    pos = 0
    for item in slist:
        send_cmd(f"slist {pos} {item}")
        pos += 1
        code = item & 0xF
        if code < 8:
            range_table.append(analog_ranges[item >> 8])
        elif code == 8:
            range_table.append(0)
        elif code == 9:
            range_table.append(rate_ranges[(item >> 8) - 1])
        else:
            range_table.append(0)

# ===================== Phidget Setup =====================

# Calibration parameters for 4 Phidget channels.
offsets = [0.0, 0.0, 0.0, 0.0]
calibrated = [False, False, False, False]
weights = [0.0, 0.0, 0.0, 0.0]

def tareScale(ch, channel_num):
    """Tare (zero) the Phidget channel by averaging a number of samples."""
    total = 0.0
    for _ in range(tare_samples):
        total += ch.getVoltageRatio()
        time.sleep(sample_interval / 1000.0)
    offsets[channel_num] = total / tare_samples
    calibrated[channel_num] = True

def init_phidget_channels():
    """Initialize and tare four Phidget channels."""
    channels = []
    for i in range(4):
        vri = VoltageRatioInput()
        vri.setChannel(i)
        vri.openWaitForAttachment(5000)
        vri.setBridgeGain(BridgeGain.BRIDGE_GAIN_128) # maximum gain
        channels.append(vri)

        print("Taring channel", i)
        tareScale(vri, i)
        print("Channel", i, "tared.")
    return channels

# ===================== Main Logging Program =====================

def main():
    phidget_channels = init_phidget_channels()

    while not discovery():
        pass

    # Configure DATAQ device
    send_cmd("stop")
    send_cmd("encode 0")
    send_cmd("ps 0")
    config_scn_lst()
    send_cmd("dec 512")
    send_cmd("srate 11718")

    print("\nReady to acquire data.")
    print("Press <g> to start, <s> to stop, <q> to quit.")

    combined_csv = "combined_data.csv"
    with open(combined_csv, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["Time (s)", "Wind Speed (m/s)", "Wind Direction (°)", "Force x (N)", "Force y (N)", "Force z (N)"])

        acquiring = False
        start_time = last_log = None
        wind_speed = wind_direction = 0.0

        while True:
            if keyboard.is_pressed('g'):
                keyboard.read_key()
                acquiring = True
                send_cmd("start")
                start_time = time.monotonic()
                last_log = start_time
                print("Acquisition started.")

            if keyboard.is_pressed('s'):
                keyboard.read_key()
                acquiring = False
                send_cmd("stop")
                ser.flushInput()
                print("Acquisition stopped.")

            if keyboard.is_pressed('q'):
                keyboard.read_key()
                send_cmd("stop")
                ser.flushInput()
                print("Quitting.")
                break

            if acquiring:
                # read all full samples in buffer
                while ser.inWaiting() >= len(slist) * 2:
                    for idx in range(len(slist)):
                        raw = ser.read(2)
                        code = slist[idx] & 0xF
                        if code < 8:
                            val = int.from_bytes(raw, byteorder="little", signed=True)
                            res = range_table[idx] * val / 32768
                            if idx == 0:
                                wind_speed = (res - 1.32) / (6.6 - 1.32) * 40
                            else:
                                wind_direction = ((res - 1.32) / (6.6 - 1.32) * 360 + 8.2) % 360
                # log
                now = time.monotonic()
                if now - last_log >= 0.1:
                    t = round(now - start_time, 5)
                    for i in range(4):
                        voltage_ratio = phidget_channels[i].getVoltageRatio()
                        weights[i] = (voltage_ratio - offsets[i]) * gains[i]
                    force_x = round((weights[0]+weights[1])/2, 5)
                    force_z = round(weights[2], 5)
                    force_y = round(weights[3], 5)
                    writer.writerow([t, round(wind_speed,5), round(wind_direction,5), force_x, force_y, force_z])
                    last_log = now
                    print(f"Logged: {t:.2f}s, {force_x}, {force_y}, {force_z}, {wind_speed:.5f} m/s, {wind_direction:.5f}°")

    ser.close()
    for ch in phidget_channels:
        ch.close()
        print(f"Closed Phidget channel {ch.getChannel()}")

if __name__ == "__main__":
    main()
