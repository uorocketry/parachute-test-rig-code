"""

    COPYRIGHT © 2018 BY DATAQ INSTRUMENTS, INC.


!!!!!!!!    VERY IMPORTANT    !!!!!!!!
!!!!!!!!    READ THIS FIRST   !!!!!!!!

This program works only with the following models:
DI-1120, -2108, -4108, -4208, AND -4718B
Any other instrument model should be disconnected from the PC
to prevent the program from detecting a device with a DATAQ
Instruments VID and attempting to use it. 
Such attempts will fail.

You'll need to uncomment the appropriate 

slist
analog_ranges

tuples for the instrument model you will use with this program.
Prototypes are provided for each supported model, so it's a
simple matter of commenting the ones that don't apply, and 
uncommenting the one that does. In its as-delivered state
the program assumes that model DI-2108 is connected. 

Instruments used with this program MUST be placed in their
CDC communication mode. 
Follow this link for guidance:
https://www.dataq.com/blog/data-acquisition/usb-daq-products-support-libusb-cdc/

Any specific instrument's protocol document can be downloaded from the instrument's 
product page: Once there, click the DETAILS tab.
"""


import serial
import serial.tools.list_ports
import keyboard
import time
import time
import csv 
import datetime

"""
Uncomment the slist tuple depending upon the hardware model you're using. 
You can modify the example tuples to change the measurement configuration
as needed. Refer to the instrument's protocol for details. Note that 
only one slist tuple can be enabled at a time. 

slist for model DI-2108
0x0000 = Analog channel 0, ±10 V range
0x0001 = Analog channel 1, ±10 V range
0x0709 = Rate input, 0-500 Hz range
0x000A = Counter input
"""
slist = [0x0000,0x0001]


"""
Uncomment an analog_ranges tuple depending upon the hardware model you're using. 
Note that only one can be enabled at a time. 
The first item in the tuple is the lowest gain code (e.g. ±100 V range = gain code 0)
for the DI-4208. Some instrument models do not support programmable gain, so 
their tuples contain only one value (e.g. model DI-2108.)
"""
# Analog ranges for model DI-2108 (fixed ±10 V measurement range)
analog_ranges = [10]

"""
Define a tuple that contains an ordered list of rate measurement ranges supported by the hardware. 
The first item in the list is the lowest gain code (e.g. 50 kHz range = gain code 1).
"""
rate_ranges = tuple((50000,20000,10000,5000,2000,1000,500,200,100,50,20,10))

# This is a list of analog and rate ranges to apply in slist order
range_table = list(())

ser=serial.Serial()

# Define flag to indicate if acquiring is active 
acquiring = False

""" Discover DATAQ Instruments devices and models.  Note that if multiple devices are connected, only the 
device discovered first is used. We leave it to you to ensure that it's the desired device model."""
def discovery():
    # Get a list of active com ports to scan for possible DATAQ Instruments devices
    available_ports = list(serial.tools.list_ports.comports())
    # Will eventually hold the com port of the detected device, if any
    hooked_port = "" 
    for p in available_ports:
        # Do we have a DATAQ Instruments device?
        if ("VID:PID=0683" in p.hwid):
            # Yes!  Dectect and assign the hooked com port
            hooked_port = p.device
            break

    if hooked_port:
        print("Found a DATAQ Instruments device on",hooked_port)
        ser.timeout = 0
        ser.port = hooked_port
        ser.baudrate = '115200'
        ser.open()
        return(True)
    else:
        # Get here if no DATAQ Instruments devices are detected
        print("Please connect a DATAQ Instruments device")
        input("Press ENTER to try again...")
        return(False)

# Sends a passed command string after appending <cr>
def send_cmd(command):
    ser.write((command+'\r').encode())
    time.sleep(.1)
    if not(acquiring):
        # Echo commands if not acquiring
        while True:
            if(ser.inWaiting() > 0):
                while True:
                    try:
                        s = ser.readline().decode()
                        s = s.strip('\n')
                        s = s.strip('\r')
                        s = s.strip(chr(0))
                        break
                    except:
                        continue
                if s != "":
                    print (s)
                    break

# Configure the instrment's scan list
def config_scn_lst():
    # Scan list position must start with 0 and increment sequentially
    position = 0 
    for item in slist:
        send_cmd("slist "+ str(position ) + " " + str(item))
        position += 1
        # Update the Range table
        if ((item) & (0xf)) < 8:
            # This is an analog channel. Refer to the slist prototype for your instrument
            # as defined in the instrument protocol. 
            range_table.append(analog_ranges[item >> 8])

        elif ((item) & (0xf)) == 8:
            # This is a dig in channel. No measurement range support. 
            # Update range_table with any value to keep it aligned.
            range_table.append(0) 

        elif ((item) & (0xf)) == 9:
            # This is a rate channel
            # Rate ranges begin with 1, so subtract 1 to maintain zero-based index
            # in the rate_ranges tuple
            range_table.append(rate_ranges[(item >> 8)-1]) 

        else:
            # This is a count channel. No measurement range support.
            # Update range_table with any value to keep it aligned.
            range_table.append(0)


import csv
import time
import datetime
import keyboard

with open('anemometer.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['Days', 'Seconds', 'Wind Speed (m/s)', 'Wind Direction (°: N(180)/S(360,0)/E(270)/W(90))'])

    start_time = time.monotonic()  # Use a monotonic clock to track elapsed time
    last_log_time = start_time  # Track last logged time

    while discovery() == False:
        discovery()

    send_cmd("stop")
    send_cmd("encode 0")
    send_cmd("ps 0")   
    config_scn_lst()
    send_cmd("dec 512")
    send_cmd("srate 11718")

    print("\nReady to acquire...\n")
    print("Press <g> to go, <s> to stop, <r> to reset counter, and <q> to quit:")

    slist_pointer = 0
    output_string = ""

    # Initialize variables
    wind_speed = None
    wind_direction = None
    acquiring = False

    # Ensure first data point at elapsed_time = 0
    writer.writerow([0, 0.00000, 0.00000, 0.00000])
    file.flush()
    print(f"Logged: 0s, 0.00000 m/s, 0.00000°")

    while True:
        # Handle user input
        if keyboard.is_pressed('g' or 'G'):
            keyboard.read_key()
            acquiring = True
            send_cmd("start")
            start_time = time.monotonic()  # Reset timer
            last_log_time = start_time

        if keyboard.is_pressed('s' or 'S'):
            keyboard.read_key()
            send_cmd("stop")
            ser.flushInput()
            print("\nStopped")
            acquiring = False

        if keyboard.is_pressed('q' or 'Q'):
            keyboard.read_key()
            send_cmd("stop")
            ser.flushInput()
            break

        if acquiring:
            # Read incoming data
            while ser.inWaiting() > len(slist):
                for i in range(len(slist)):
                    function = (slist[slist_pointer]) & (0xf)
                    bytes_data = ser.read(2)

                    if function < 8:
                        min_voltage = 1.32  
                        max_voltage = 6.6  
                        result = range_table[slist_pointer] * int.from_bytes(bytes_data, byteorder='little', signed=True) / 32768

                        if slist_pointer == 0:
                            new_wind_speed = max(0, min(40, (result - min_voltage) / (max_voltage - min_voltage) * 40))
                            wind_speed = new_wind_speed
                            output_string += "Wind Speed: {: 3.5f} m/s, ".format(wind_speed)

                        elif slist_pointer == 1:
                            new_wind_direction = ((result - min_voltage) / (max_voltage - min_voltage) * 360 + 8.2) % 360
                            wind_direction = new_wind_direction
                            output_string += "Wind Direction: {: 3.5f}°, ".format(wind_direction)

                    slist_pointer += 1
                    if slist_pointer >= len(slist):
                        output_string = ""
                        slist_pointer = 0

            # Check if 0.5s has elapsed
            current_time = time.monotonic()
            if current_time - last_log_time >= 0.5:
                elapsed_time = current_time - start_time
                writer.writerow([0, round(elapsed_time, 5), round(wind_speed, 5), round(wind_direction, 5)])
                file.flush()
                print(f"Logged: {elapsed_time:.2f}s, {wind_speed:.5f} m/s, {wind_direction:.5f}°")
                last_log_time = current_time  # Update last log time

ser.close()

